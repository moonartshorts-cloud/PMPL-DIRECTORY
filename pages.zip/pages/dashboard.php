
<?php include '../includes/session.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>Employee Directory</title>
<link rel="stylesheet" href="../assets/css/style.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<header class="header">
 <div class="brand">📒 Employee Directory</div>
 <div class="user">👤 <?=$_SESSION['user']?> (<?=$_SESSION['role']?>)</div>
</header>

<div class="app">
<?php if($_SESSION['role']==='ADMIN'): ?>
<aside class="sidebar">
 <button onclick="showEmp()">📘 Book Entry</button>
 <button onclick="showUser()">➕ Add User</button>
 <button onclick="showBulk()">📤 Bulk Upload</button>
</aside>
<?php endif; ?>

<main class="main">
 <input id="search" placeholder="Search by name, dept, email, mobile...">
 <div class="table-wrap">
  <table id="tbl">
   <thead>
    <tr>
     <th>Name</th><th>Emp Code</th><th>Department</th>
     <th>Designation</th><th>Site</th><th>Mobile</th><th>Email</th>
    </tr>
   </thead>
   <tbody></tbody>
  </table>
 </div>
</main>
</div>

<!-- Modals -->
<div class="modal" id="empModal"><div class="modal-box">
<h3>📘 Book Entry</h3>
<input id="en" placeholder="Name">
<input id="ec" placeholder="Emp Code">
<input id="ed" placeholder="Department">
<input id="eg" placeholder="Designation">
<input id="es" placeholder="Site Name">
<input id="em" placeholder="Mobile">
<input id="ee" placeholder="Email">
<button onclick="addEmp()">Save</button>
<button onclick="hide()">Close</button>
</div></div>

<div class="modal" id="userModal"><div class="modal-box">
<h3>➕ Add User</h3>
<input id="nu" placeholder="Username">
<input id="np" placeholder="Password">
<select id="nr"><option>USER</option><option>ADMIN</option></select>
<button onclick="addUser()">Save</button>
<button onclick="hide()">Close</button>
</div></div>

<div class="modal" id="bulkModal"><div class="modal-box">
<h3>📤 Bulk Upload</h3>
<a href="../templates/employee_template.csv" download>⬇ Download Template</a>
<form method="post" enctype="multipart/form-data" action="../api/bulk_upload.php">
<input type="file" name="file" accept=".csv" required>
<button type="submit">Upload</button>
<button type="button" onclick="hide()">Close</button>
</form>
</div></div>

<script>
function load(){
 fetch('../api/employees.php?search='+search.value)
 .then(r=>r.json()).then(d=>{
  let b=document.querySelector('#tbl tbody'); b.innerHTML='';
  d.forEach(e=>{
   b.innerHTML+=`<tr>
   <td>${e.name||''}</td><td>${e.emp_code||''}</td>
   <td>${e.department||''}</td><td>${e.designation||''}</td>
   <td>${e.site_name||''}</td><td>${e.mobile||''}</td><td>${e.email||''}</td>
   </tr>`;
  });
 });
}
search.onkeyup=load; load();

function showEmp(){empModal.style.display='flex';}
function showUser(){userModal.style.display='flex';}
function showBulk(){bulkModal.style.display='flex';}
function hide(){empModal.style.display='none';userModal.style.display='none';bulkModal.style.display='none';}

function addEmp(){
 fetch('../api/add_employee.php',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({
  name:en.value,emp_code:ec.value,department:ed.value,
  designation:eg.value,site_name:es.value,mobile:em.value,email:ee.value
 })}).then(r=>r.json()).then(d=>{if(d.success){hide();load();}});
}

function addUser(){
 fetch('../api/add_user.php',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({username:nu.value,password:np.value,role:nr.value})})
 .then(r=>r.json()).then(d=>{alert(d.success?'User added':d.msg);hide();});
}
</script>
</body>
</html>
